﻿using System.Collections.Generic;

namespace SIS.MvcFramework.Tests
{
    public class TestViewModel
    {
        public string StringValue { get; set; }

        public IEnumerable<string> ListValues { get; set; }
    }
}

﻿namespace SULS.App.ViewModels.Problems
{
    public class ProblemSubmissionViewModel
    {
        public string ProblemId { get; set; }
        public string Name { get; set; }
    }
}

﻿namespace SULS.App.ViewModels.Home
{
    public class ProblemHomeViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
    }
}

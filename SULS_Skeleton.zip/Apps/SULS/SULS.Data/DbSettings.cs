﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SULS.Data
{
    public class DbSettings
    {
        public const string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=SULSDb-AntoninaKoleva;Trusted_Connection=True;Integrated Security=True;";
    }
}
